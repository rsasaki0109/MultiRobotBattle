"""Optimal shooter–target assignment for swarm battle.

Uses the repo's :func:`hungarian` allocator to pick a team-wide matching of
allies to enemies each replan tick — who engages whom — while the tactics
policy still sets pursue / flock / retreat scales.
"""

from __future__ import annotations

import math

from .lifelong.allocation import INF, hungarian

_ASSIGNMENT_MODES = ("none", "hungarian")


def assignment_cost(shooter, enemy, dist, cfg):
    """Lower is better: prefer in-range, wounded, and nearer targets."""
    b_range = (shooter.attack_range if shooter.attack_range is not None
               else cfg.attack_range)
    cost = dist
    if dist > b_range:
        cost += 8.0 + 2.0 * (dist - b_range)
    hp_frac = enemy.hp / enemy.max_hp if enemy.max_hp else 1.0
    cost -= 2.5 * (1.0 - hp_frac)
    if shooter.kind == "sniper":
        ideal = 0.85 * b_range
        cost += abs(dist - ideal)
        if dist < 0.35 * b_range:
            cost += 4.0
    return cost


def hungarian_assignments(live, cfg):
    """Per live-index target for bots on teams using Hungarian assignment."""
    by_team = {}
    for i, b in enumerate(live):
        by_team.setdefault(b.team, []).append(i)

    targets = {}
    for team, allies in by_team.items():
        mode = (cfg.assignment_by_team or {}).get(team, cfg.assignment)
        if mode not in ("hungarian",):
            continue
        enemies = [j for j, b in enumerate(live) if b.team != team]
        if not enemies:
            continue
        if len(allies) == 1:
            best = min(enemies, key=lambda j: math.hypot(
                live[allies[0]].x - live[j].x, live[allies[0]].y - live[j].y))
            targets[allies[0]] = best
            continue
        cost = []
        for ai in allies:
            row = []
            sh = live[ai]
            for ej in enemies:
                en = live[ej]
                d = math.hypot(sh.x - en.x, sh.y - en.y)
                row.append(assignment_cost(sh, en, d, cfg))
            cost.append(row)
        matching = hungarian(cost)
        for r, c in matching.items():
            targets[allies[r]] = enemies[c]
        for ai in allies:
            if ai not in targets:
                targets[ai] = min(enemies, key=lambda j, ai=ai: math.hypot(
                    live[ai].x - live[j].x, live[ai].y - live[j].y))
    return targets


def apply_assignments(decisions, live, cfg):
    """Override policy targets for teams with ``assignment='hungarian'``."""
    if cfg.assignment in (None, "", "none") and not cfg.assignment_by_team:
        return decisions
    assigns = hungarian_assignments(live, cfg)
    if not assigns:
        return decisions
    out = list(decisions)
    for i, decision in enumerate(out):
        if decision is None or i not in assigns:
            continue
        t = assigns[i]
        out[i] = type(decision)(
            target_index=t,
            pursue_scale=decision.pursue_scale,
            retreat_scale=decision.retreat_scale,
            flock_scale=decision.flock_scale,
            kite=decision.kite,
        )
    return out
